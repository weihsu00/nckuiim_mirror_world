<?php
header("Expires: Mon, 26 Jul 2015 05:00:00 GMT");

$Shirt_Note = $_POST["Shirt_Note"];

$Shirt_Amount = $_POST["Shirt_Amount"];

$Shirt_Length = $_POST["Shirt_Length"];

$Shirt_Sleeve = $_POST["Shirt_Sleeve"];

$Shirt_Shoulder = $_POST["Shirt_Shoulder"];
if (empty($Shirt_Shoulder)) {
  $Shirt_Shoulder = "0";
}
$Shirt_Shoulder_Front = $_POST["Shirt_Shoulder_Front"];
if (empty($Shirt_Shoulder_Front)) {
  $Shirt_Shoulder_Front = "0";
}
$Shirt_Bust = $_POST["Shirt_Bust"];
if (empty($Shirt_Bust)) {
  $Shirt_Bust = "0";
}
$Shirt_Bust_Length = $_POST["Shirt_Bust_Length"];
if (empty($Shirt_Bust_Length)) {
  $Shirt_Bust_Length = "0";
}
$Shirt_Bust_Width = $_POST["Shirt_Bust_Width"];
if (empty($Shirt_Bust_Width)) {
  $Shirt_Bust_Width = "0";
}
$Shirt_Waist = $_POST["Shirt_Waist"];
if (empty($Shirt_Waist)) {
  $Shirt_Waist = "0";
}
$Shirt_Middle_Hip = $_POST["Shirt_Middle_Hip"];
if (empty($Shirt_Middle_Hip)) {
  $Shirt_Middle_Hip = "0";
}
$Shirt_Hip = $_POST["Shirt_Hip"];
if (empty($Shirt_Hip)) {
  $Shirt_Hip = "0";
}
$Shirt_Front_Amhole = $_POST["Shirt_Front_Amhole"];
if (empty($Shirt_Front_Amhole)) {
  $Shirt_Front_Amhole = "0";
}
$Shirt_Behind_Amhole = $_POST["Shirt_Behind_Amhole"];
if (empty($Shirt_Behind_Amhole)) {
  $Shirt_Behind_Amhole = "0";
}
$Shirt_Across_Front = $_POST["Shirt_Across_Front"];
if (empty($Shirt_Across_Front)) {
  $Shirt_Across_Front = "0";
}
$Shirt_Across_Back = $_POST["Shirt_Across_Back"];
if (empty($Shirt_Across_Back)) {
  $Shirt_Across_Back = "0";
}
$Shirt_Unit_Price = $_POST["Shirt_Unit_Price"];
if (empty($Shirt_Unit_Price)) {
  $Shirt_Unit_Price = "0";
}

$result = "-1";  // 新增記錄失敗

   $db = mysqli_connect("localhost", "root", "t19950515");
   @mysqli_query($db,"SET NAMES utf8");
   mysqli_select_db($db, "mirrorworld");


   if (!(empty($Shirt_Note) || empty($Shirt_Amount) || empty($Shirt_Length) || empty($Shirt_Sleeve))) {
   		$sql = "INSERT INTO order_information_shirt "."(Shirt_Note, Shirt_Amount, Shirt_Length, Shirt_Sleeve, Shirt_Shoulder, Shirt_Shoulder_Front, Shirt_Bust, Shirt_Bust_Length, Shirt_Bust_Width, Shirt_Waist, Shirt_Middle_Hip, Shirt_Hip, Shirt_Front_Amhole, Shirt_Behind_Amhole, Shirt_Across_Front, Shirt_Across_Back, Shirt_Unit_Price) VALUES ('$Shirt_Note', '$Shirt_Amount', '$Shirt_Length', '$Shirt_Sleeve', '$Shirt_Shoulder', '$Shirt_Shoulder_Front', '$Shirt_Bust', '$Shirt_Bust_Length', '$Shirt_Bust_Width', '$Shirt_Waist', '$Shirt_Middle_Hip', '$Shirt_Hip', '$Shirt_Front_Amhole', '$Shirt_Behind_Amhole', '$Shirt_Across_Front', '$Shirt_Across_Back', '$Shirt_Unit_Price')";
		   if (mysqli_query($db, $sql)) { // 執行SQL指令
          		$result = "1"; // 新增記錄成功
      		}
   	}
   
echo $result;
mysqli_close($db);
?> 
