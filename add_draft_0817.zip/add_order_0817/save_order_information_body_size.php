<?php
header("Expires: Mon, 26 Jul 2015 05:00:00 GMT");
$Neck = $_POST["Neck"];
if (empty($Neck)) {
	$Neck = "0";
}
$Shoulder = $_POST["Shoulder"];
if (empty($Shoulder)) {
	$Shoulder = "0";
}
$Upper_Bust = $_POST["Upper_Bust"];
if (empty($Upper_Bust)) {
	$Upper_Bust = "0";
}
$Bust = $_POST["Bust"];
if (empty($Bust)) {
	$Bust = "0";
}
$Lower_Bust = $_POST["Lower_Bust"];
if (empty($Lower_Bust)) {
	$Lower_Bust = "0";
}
$Waist = $_POST["Waist"];
if (empty($Waist)) {
	$Waist = "0";
}
$Belly = $_POST["Belly"];
if (empty($Belly)) {
	$Belly = "0";
}
$Middle_Hip = $_POST["Middle_Hip"];
if (empty($Middle_Hip)) {
	$Middle_Hip = "0";
}
$Hip = $_POST["Hip"];
if (empty($Hip)) {
	$Hip = "0";
}
$Hindquarter = $_POST["Hindquarter"];
if (empty($Hindquarter)) {
   $Hindquarter = "0";
}
$Crotch = $_POST["Crotch"];
if (empty($Crotch)) {
   $Crotch = "0";
}
$Under_Crotch = $_POST["Under_Crotch"];
if (empty($Under_Crotch)) {
   $Under_Crotch = "0";
}
$Upper_Knee = $_POST["Upper_Knee"];
if (empty($Upper_Knee)) {
   $Upper_Knee = "0";
}
$Back = $_POST["Back"];
if (empty($Back)) {
   $Back = "0";
}
$Armhole = $_POST["Armhole"];
if (empty($Armhole)) {
   $Armhole = "0";
}
$Arm = $_POST["Arm"];
if (empty($Arm)) {
   $Arm = "0";
}

$result = "-1";  // 新增記錄失敗

   $db = mysqli_connect("localhost", "root", "t19950515");
   @mysqli_query($db,"SET NAMES utf8");
   mysqli_select_db($db, "mirrorworld");

   $sql = "INSERT INTO order_information_body_size ".
"(Neck, Shoulder, Upper_Bust, Bust, Lower_Bust, Waist, Belly, Middle_Hip, Hip, Hindquarter, Crotch, Under_Crotch, Upper_Knee, Back, Armhole, Arm) VALUES ('$Neck', '$Shoulder', '$Upper_Bust', '$Bust', '$Lower_Bust', '$Waist', '$Belly', '$Middle_Hip', '$Hip', '$Hindquarter', '$Crotch', '$Under_Crotch', '$Upper_Knee', '$Back', '$Armhole', '$Arm')";

      if (mysqli_query($db, $sql)) { // 執行SQL指令
          $result = "1"; // 新增記錄成功
      }     
echo $result;
mysqli_close($db);
?> 
