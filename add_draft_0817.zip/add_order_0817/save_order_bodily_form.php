<?php
header("Expires: Mon, 26 Jul 2015 05:00:00 GMT");

$Order_Bodily_Form_Style_ID = $_POST["Order_Bodily_Form_Style_ID"];

$result = "1";  // 新增記錄失敗

   $db = mysqli_connect("localhost", "root", "t19950515");
   @mysqli_query($db,"SET NAMES utf8");
   mysqli_select_db($db, "mirrorworld");


   if (!empty($Order_Bodily_Form_Style_ID[0])) {
   		$result = "-1";
   		$sql = "INSERT INTO order_bodily_form "."(Order_Bodily_Form_Style_ID) VALUES ('$Order_Bodily_Form_Style_ID[0]')";
		   if (mysqli_query($db, $sql)) { // 執行SQL指令
          		$result = "1"; // 新增記錄成功
      		}
   	}

   if (!empty($Order_Bodily_Form_Style_ID[1])) {
   		$result = "-1";
   		$sql = "INSERT INTO order_bodily_form "."(Order_Bodily_Form_Style_ID) VALUES ('$Order_Bodily_Form_Style_ID[1]')";
		   if (mysqli_query($db, $sql)) { // 執行SQL指令
          		$result = "1"; // 新增記錄成功
      		}
   	}

   if (!empty($Order_Bodily_Form_Style_ID[2])) {
   		$result = "-1";
   		$sql = "INSERT INTO order_bodily_form "."(Order_Bodily_Form_Style_ID) VALUES ('$Order_Bodily_Form_Style_ID[2]')";
		   if (mysqli_query($db, $sql)) { // 執行SQL指令
          		$result = "1"; // 新增記錄成功
      		}
   	}

   if (!empty($Order_Bodily_Form_Style_ID[3])) {
   		$result = "-1";
   		$sql = "INSERT INTO order_bodily_form "."(Order_Bodily_Form_Style_ID) VALUES ('$Order_Bodily_Form_Style_ID[3]')";
		   if (mysqli_query($db, $sql)) { // 執行SQL指令
          		$result = "1"; // 新增記錄成功
      		}
   	}

   if (!empty($Order_Bodily_Form_Style_ID[4])) {
   		$result = "-1";
   		$sql = "INSERT INTO order_bodily_form "."(Order_Bodily_Form_Style_ID) VALUES ('$Order_Bodily_Form_Style_ID[4]')";
		   if (mysqli_query($db, $sql)) { // 執行SQL指令
          		$result = "1"; // 新增記錄成功
      		}
   	}

   if (!empty($Order_Bodily_Form_Style_ID[5])) {
   		$result = "-1";
   		$sql = "INSERT INTO order_bodily_form "."(Order_Bodily_Form_Style_ID) VALUES ('$Order_Bodily_Form_Style_ID[5]')";
		   if (mysqli_query($db, $sql)) { // 執行SQL指令
          		$result = "1"; // 新增記錄成功
      		}
   	}

   if (!empty($Order_Bodily_Form_Style_ID[6])) {
   		$result = "-1";
   		$sql = "INSERT INTO order_bodily_form "."(Order_Bodily_Form_Style_ID) VALUES ('$Order_Bodily_Form_Style_ID[6]')";
		   if (mysqli_query($db, $sql)) { // 執行SQL指令
          		$result = "1"; // 新增記錄成功
      		}
   	}

   if (!empty($Order_Bodily_Form_Style_ID[7])) {
   		$result = "-1";
   		$sql = "INSERT INTO order_bodily_form "."(Order_Bodily_Form_Style_ID) VALUES ('$Order_Bodily_Form_Style_ID[7]')";
		   if (mysqli_query($db, $sql)) { // 執行SQL指令
          		$result = "1"; // 新增記錄成功
      		}
   	}    
   
echo $result;
mysqli_close($db);
?> 
