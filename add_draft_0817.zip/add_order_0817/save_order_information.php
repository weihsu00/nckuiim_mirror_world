<?php
header("Expires: Mon, 26 Jul 2015 05:00:00 GMT");
$Company = $_POST["Company"];
if (empty($Company)) {
	$Company = "0";
}
$Customer_Name = $_POST["Customer_Name"];

$Height = $_POST["Height"];
if (empty($Height)) {
	$Height = "0";
}  
$Weight = $_POST["Weight"];
if (empty($Weight)) {
	$Weight = "0";
}  
$Customer_Phone = $_POST["Customer_Phone"];
if (empty($Customer_Phone)) {
	$Customer_Phone = "0";
}
$Sex_ID = $_POST["Sex_ID"];

$Shirt_Size = $_POST["Shirt_Size"];
if (empty($Shirt_Size)) {
	$Shirt_Size = "0";
}
$Jacket_Size = $_POST["Jacket_Size"];
if (empty($Jacket_Size)) {
	$Jacket_Size = "0";
}
$Vest_Size = $_POST["Vest_Size"];
if (empty($Vest_Size)) {
	$Vest_Size = "0";
}
$Skirt_Size = $_POST["Skirt_Size"];
if (empty($Skirt_Size)) {
	$Skirt_Size = "0";
}
$Pant_Size = $_POST["Pant_Size"];
if (empty($Pant_Size)) {
	$Pant_Size = "0";
}
$Serial_Price = $_POST["Serial_Price"];
if (empty($Serial_Price)) {
	$Serial_Price = "0";
}
$Serial_Deposit = $_POST["Serial_Deposit"];
if (empty($Serial_Deposit)) {
	$Serial_Deposit = "0";
}
$Company_Footnote = $_POST["Company_Footnote"];
if (empty($Company_Footnote)) {
	$Company_Footnote = "0";
}
$Factory_Footnote = $_POST["Factory_Footnote"];
if (empty($Factory_Footnote)) {
	$Factory_Footnote = "0";
}
$result = "-1";  // 新增記錄失敗


   $db = mysqli_connect("localhost", "root", "t19950515");
   @mysqli_query($db,"SET NAMES utf8");
   mysqli_select_db($db, "mirrorworld");

   if(!(empty($Customer_Name) || empty($Sex_ID))){

   	$sql = "INSERT INTO order_information "."(Company, Customer_Name, Height, Weight, Customer_Phone, Sex_ID, Shirt_Size, Jacket_Size, Vest_Size, Skirt_Size, Pant_Size, Serial_Price, Serial_Deposit, Company_Footnote, Factory_Footnote) VALUES ('$Company',  '$Customer_Name', '$Height', '$Weight', '$Customer_Phone', '$Sex_ID[0]', '$Shirt_Size', '$Jacket_Size', '$Vest_Size', '$Skirt_Size', '$Pant_Size', '$Serial_Price', '$Serial_Deposit', '$Company_Footnote', '$Factory_Footnote')";

      if (mysqli_query($db, $sql)) { // 執行SQL指令
          $result = "1"; // 新增記錄成功
      }
   }   
   
echo $result;
mysqli_close($db);
?> 
