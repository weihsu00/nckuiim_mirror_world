<?php
header("Expires: Mon, 26 Jul 2015 05:00:00 GMT");
$Pant_Note = $_POST["Pant_Note"];

$Pant_Amount = $_POST["Pant_Amount"];

$Pant_Length = $_POST["Pant_Length"];

$Pant_Waist = $_POST["Pant_Waist"];

$Pant_Middle_Hip = $_POST["Pant_Middle_Hip"];
if (empty($Pant_Middle_Hip)) {
  $Pant_Middle_Hip = "0";
}
$Pant_Hip = $_POST["Pant_Hip"];
if (empty($Pant_Hip)) {
  $Pant_Hip = "0";
}
$Pant_Crotch = $_POST["Pant_Crotch"];
if (empty($Pant_Crotch)) {
   $Pant_Crotch = "0";
}
$Pant_Full_Rise = $_POST["Pant_Full_Rise"];

$Pant_Front_Rise = $_POST["Pant_Front_Rise"];
if (empty($Pant_Front_Rise)) {
   $Pant_Front_Rise = "0";
}
$Pant_Back_Rise = $_POST["Pant_Back_Rise"];
if (empty($Pant_Back_Rise)) {
   $Pant_Back_Rise = "0";
}
$Pant_Knee = $_POST["Pant_Knee"];
if (empty($Pant_Knee)) {
   $Pant_Knee = "0";
}
$Pant_Foot = $_POST["Pant_Foot"];
if (empty($Pant_Foot)) {
   $Pant_Foot = "0";
}
$Pant_Style_ID = $_POST["Pant_Style_ID"];
if (empty($Pant_Style_ID)) {
   $Pant_Style_ID = "0";
}
$Pant_Unit_Price = $_POST["Pant_Unit_Price"];
if (empty($Pant_Unit_Price)) {
   $Pant_Unit_Price = "0";
}

$result = "-1";  // 新增記錄失敗

   $db = mysqli_connect("localhost", "root", "t19950515");
   @mysqli_query($db,"SET NAMES utf8");
   mysqli_select_db($db, "mirrorworld");

   if (!(empty($Pant_Note)||empty($Pant_Amount)||empty($Pant_Length)||empty($Pant_Waist)||empty($Pant_Full_Rise))) {
      $sql = "INSERT INTO order_information_pant"."(Pant_Note, Pant_Amount, Pant_Length, Pant_Waist, Pant_Full_Rise, Pant_Middle_Hip, Pant_Hip, Pant_Crotch, Pant_Front_Rise, Pant_Back_Rise, Pant_Knee,  Pant_Foot, Pant_Style_ID, Pant_Unit_Price) VALUES ('$Pant_Note', '$Pant_Amount', '$Pant_Length', '$Pant_Waist','$Pant_Full_Rise', '$Pant_Middle_Hip', '$Pant_Hip', '$Pant_Crotch', '$Pant_Front_Rise', '$Pant_Back_Rise', '$Pant_Knee', '$Pant_Foot', '$Pant_Style_ID', '$Pant_Unit_Price')";
       if (mysqli_query($db, $sql)) { // 執行SQL指令
              $result = "1"; // 新增記錄成功
          }
   }

echo $result;
mysqli_close($db);
?> 
