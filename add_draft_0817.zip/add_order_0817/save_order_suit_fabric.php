<?php
header("Expires: Mon, 26 Jul 2015 05:00:00 GMT");
$Shirting_Fabric_1 = $_POST["Shirting_Fabric_1"];
$Shirting_Fabric_2 = $_POST["Shirting_Fabric_2"];
$Shirting_Fabric_3 = $_POST["Shirting_Fabric_3"];
$Shirting_Fabric_4 = $_POST["Shirting_Fabric_4"];
$Shirting_Fabric_5 = $_POST["Shirting_Fabric_5"];


$result = "-1";  // 新增記錄失敗

   $db = mysqli_connect("localhost", "root", "t19950515");
   @mysqli_query($db,"SET NAMES utf8");
   mysqli_select_db($db, "mirrorworld");

   if (!empty($Shirting_Fabric_1)) {
   		$sql = "INSERT INTO order_shirting "."(Shirting_Fabric) VALUES ('$Shirting_Fabric_1')";
		   if (mysqli_query($db, $sql)) { // 執行SQL指令
          		$result = "1"; // 新增記錄成功
      		}
   	}
   if (!empty($Shirting_Fabric_2)) {
   		$sql = "INSERT INTO order_shirting "."(Shirting_Fabric) VALUES ('$Shirting_Fabric_2')";
		   if (mysqli_query($db, $sql)) { // 執行SQL指令
          		$result = "1"; // 新增記錄成功
      		}
   	}
   if (!empty($Shirting_Fabric_3)) {
   		$sql = "INSERT INTO order_shirting "."(Shirting_Fabric) VALUES ('$Shirting_Fabric_3')";
		   if (mysqli_query($db, $sql)) { // 執行SQL指令
          		$result = "1"; // 新增記錄成功
      		}
   	}
   	if (!empty($Shirting_Fabric_4)) {
   		$sql = "INSERT INTO order_shirting "."(Shirting_Fabric) VALUES ('$Shirting_Fabric_4')";
		   if (mysqli_query($db, $sql)) { // 執行SQL指令
          		$result = "1"; // 新增記錄成功
      		}
   	}
   	if (!empty($Shirting_Fabric_5)) {
   		$sql = "INSERT INTO order_shirting "."(Shirting_Fabric) VALUES ('$Shirting_Fabric_5')";
		   if (mysqli_query($db, $sql)) { // 執行SQL指令
          		$result = "1"; // 新增記錄成功
      		}
   	}

echo $result;
mysqli_close($db);
?> 
