
$.noConflict();
jQuery(document).ready(function($) {
  $("form[name=order_information]").submit(function () {
    // 使用HTTP POST方法送出Ajax請求
    $.ajax({
      type: 'POST',
      url: 'save_order_information.php',
      data: $('#order_information').serialize(),
      error: function() {
        alert('save_order_information.php失敗！');
      },
      success: function (data) {
        var value = parseInt(data);
        if(value==1){
                $.ajax({
                type: 'POST',
                url: 'save_order_information_body_size.php',
                data: $('#order_information').serialize(),
                error: function() {
                  alert('save_order_information_body_size.php失敗！');},
                success: function (data) {
                var value = parseInt(data);
                if(value==1){
                
                window.opener.location.reload();
                window.close();
                } 
          else {
            alert('body_size新增失敗！');}
            }
             });
        } 
          else {
            alert('order_information & body_size新增失敗！');
          }
      }
    });

    $.ajax({
      type: 'POST',
      url: 'save_order_shirting.php',
      data: $('#order_information').serialize(),
      error: function() {
        alert('save_order_shirting.php失敗！');
      },
      success: function (data) {
          var value = parseInt(data);
          if(value==1){
            
            window.opener.location.reload();
            window.close();
          } 
          else {
            alert('shirting新增失敗！');
          }
      }
    });

    $.ajax({
      type: 'POST',
      url: 'save_order_suit_fabric.php',
      data: $('#order_information').serialize(),
      error: function() {
        alert('save_order_suit_fabric.php失敗！');
      },
      success: function (data) {
          var value = parseInt(data);
          if(value==1){
            
            window.opener.location.reload();
            window.close();
          } 
          else {
            alert('suit_fabric新增失敗！');
          }
      }
    });

    $.ajax({
      type: 'POST',
      url: 'save_order_bodily_form.php',
      data: $('#order_information').serialize(),
      error: function() {
        alert('save_order_bodily_form.php失敗！');
      },
      success: function (data) {
          var value = parseInt(data);
          if(value==1){
            
            window.opener.location.reload();
            window.close();
          }
          else if (value==2) {
            alert('未輸入bodily_form！');
          } 
          else {
            alert('bodily_form新增失敗！');
          }
      }
    });

    $.ajax({
      type: 'POST',
      url: 'save_order_information_shirt.php',
      data: $('#order_information').serialize(),
      error: function() {
        alert('save_order_information_shirt.php失敗！');
      },
      success: function (data) {
          var value = parseInt(data);
          if(value==1){
            
            window.opener.location.reload();
            window.close();
          } 
          else {
            alert('shirt新增失敗！');
          }
      }
    });

    $.ajax({
      type: 'POST',
      url: 'save_order_information_jacket.php',
      data: $('#order_information').serialize(),
      error: function() {
        alert('save_order_information_jacket.php失敗！');
      },
      success: function (data) {
          var value = parseInt(data);
          if(value==1){
            
            window.opener.location.reload();
            window.close();
          } 
          else {
            alert('jacket新增失敗！');
          }
      }
    });

    $.ajax({
      type: 'POST',
      url: 'save_order_information_vest.php',
      data: $('#order_information').serialize(),
      error: function() {
        alert('save_order_information_vest.php失敗！');
      },
      success: function (data) {
          var value = parseInt(data);
          if(value==1){
            
            window.opener.location.reload();
            window.close();
          } 
          else {
            alert('vest新增失敗！');
          }
      }
    });

    $.ajax({
      type: 'POST',
      url: 'save_order_information_skirt.php',
      data: $('#order_information').serialize(),
      error: function() {
        alert('save_order_information_skirt.php失敗！');
      },
      success: function (data) {
          var value = parseInt(data);
          if(value==1){
            
            window.opener.location.reload();
            window.close();
          } 
          else {
            alert('skirt新增失敗！');
          }
      }
    });

    $.ajax({
      type: 'POST',
      url: 'save_order_information_pant.php',
      data: $('#order_information').serialize(),
      error: function() {
        alert('save_order_information_pant.php失敗！');
      },
      success: function (data) {
          var value = parseInt(data);
          if(value==1){
            
            window.opener.location.reload();
            window.close();
          } 
          else {
            alert('pant新增失敗！');
          }
      }
    });

    return false;
  });
});