<?php
header("Expires: Mon, 26 Jul 2015 05:00:00 GMT");

$Vest_Note = $_POST["Vest_Note"];

$Vest_Amount = $_POST["Vest_Amount"];

$Vest_Length = $_POST["Vest_Length"];

$Vest_Shoulder_Point = $_POST["Vest_Shoulder_Point"];
if (empty($Vest_Shoulder_Point)) {
  $Vest_Shoulder_Point = "0";
}

$Vest_Shoulder = $_POST["Vest_Shoulder"];
if (empty($Vest_Shoulder)) {
  $Vest_Shoulder = "0";
}
$Vest_Shoulder_Front = $_POST["Vest_Shoulder_Front"];
if (empty($Vest_Shoulder_Front)) {
  $Vest_Shoulder_Front = "0";
}
$Vest_Bust = $_POST["Vest_Bust"];
if (empty($Vest_Bust)) {
  $Vest_Bust = "0";
}
$Vest_Bust_Length = $_POST["Vest_Bust_Length"];
if (empty($Vest_Bust_Length)) {
  $Vest_Bust_Length = "0";
}
$Vest_Bust_Width = $_POST["Vest_Bust_Width"];
if (empty($Vest_Bust_Width)) {
  $Vest_Bust_Width = "0";
}
$Vest_Waist = $_POST["Vest_Waist"];
if (empty($Vest_Waist)) {
  $Vest_Waist = "0";
}
$Vest_Middle_Hip = $_POST["Vest_Middle_Hip"];
if (empty($Vest_Middle_Hip)) {
  $Vest_Middle_Hip = "0";
}
$Vest_Hip = $_POST["Vest_Hip"];
if (empty($Vest_Hip)) {
  $Vest_Hip = "0";
}
$Vest_Front_Amhole = $_POST["Vest_Front_Amhole"];
if (empty($Vest_Front_Amhole)) {
  $Vest_Front_Amhole = "0";
}
$Vest_Behind_Amhole = $_POST["Vest_Behind_Amhole"];
if (empty($Vest_Behind_Amhole)) {
  $Vest_Behind_Amhole = "0";
}
$Vest_Across_Front = $_POST["Vest_Across_Front"];
if (empty($Vest_Across_Front)) {
  $Vest_Across_Front = "0";
}
$Vest_Across_Back = $_POST["Vest_Across_Back"];
if (empty($Vest_Across_Back)) {
  $Vest_Across_Back = "0";
}
$Vest_Unit_Price = $_POST["Vest_Unit_Price"];
if (empty($Vest_Unit_Price)) {
  $Vest_Unit_Price = "0";
}

$result = "-1";  // 新增記錄失敗

   $db = mysqli_connect("localhost", "root", "t19950515");
   @mysqli_query($db,"SET NAMES utf8");
   mysqli_select_db($db, "mirrorworld");


   if (!(empty($Vest_Note) || empty($Vest_Amount) || empty($Vest_Length))) {
   		$sql = "INSERT INTO order_information_vest "."(Vest_Note, Vest_Amount, Vest_Length, Vest_Shoulder_Point, Vest_Shoulder, Vest_Shoulder_Front, Vest_Bust, Vest_Bust_Length, Vest_Bust_Width, Vest_Waist, Vest_Middle_Hip, Vest_Hip, Vest_Front_Amhole, Vest_Behind_Amhole, Vest_Across_Front, Vest_Across_Back, Vest_Unit_Price) VALUES ('$Vest_Note', '$Vest_Amount', '$Vest_Length', '$Vest_Shoulder_Point', '$Vest_Shoulder', '$Vest_Shoulder_Front', '$Vest_Bust', '$Vest_Bust_Length', '$Vest_Bust_Width', '$Vest_Waist', '$Vest_Middle_Hip', '$Vest_Hip', '$Vest_Front_Amhole', '$Vest_Behind_Amhole', '$Vest_Across_Front', '$Vest_Across_Back', '$Vest_Unit_Price')";
		   if (mysqli_query($db, $sql)) { // 執行SQL指令
          		$result = "1"; // 新增記錄成功
      		}
   	}
   
echo $result;
mysqli_close($db);
?> 
