<?php
header("Expires: Mon, 26 Jul 2015 05:00:00 GMT");

$Jacket_Note = $_POST["Jacket_Note"];
$Jacket_Amount = $_POST["Jacket_Amount"];
$Jacket_Length = $_POST["Jacket_Length"];
$Jacket_Sleeve = $_POST["Jacket_Sleeve"];
$Jacket_Shoulder = $_POST["Jacket_Shoulder"];
if (empty($Jacket_Shoulder)) {
  $Jacket_Shoulder = "0";
}
$Jacket_Shoulder_Front = $_POST["Jacket_Shoulder_Front"];
if (empty($Jacket_Shoulder)) {
  $Jacket_Shoulder = "0";
}
$Jacket_Bust = $_POST["Jacket_Bust"];
if (empty($Jacket_Bust)) {
  $Jacket_Bust = "0";
}
$Jacket_Bust_Length = $_POST["Jacket_Bust_Length"];
if (empty($Jacket_Bust_Length)) {
  $Jacket_Bust_Length = "0";
}
$Jacket_Bust_Width = $_POST["Jacket_Bust_Width"];
if (empty($Jacket_Bust_Width)) {
  $Jacket_Bust_Width = "0";
}
$Jacket_Waist = $_POST["Jacket_Waist"];
if (empty($Jacket_Waist)) {
  $Jacket_Waist = "0";
}
$Jacket_Middle_Hip = $_POST["Jacket_Middle_Hip"];
if (empty($Jacket_Middle_Hip)) {
  $Jacket_Middle_Hip = "0";
}
$Jacket_Hip = $_POST["Jacket_Hip"];
if (empty($Jacket_Hip)) {
  $Jacket_Hip = "0";
}
$Jacket_Front_Amhole = $_POST["Jacket_Front_Amhole"];
if (empty($Jacket_Front_Amhole)) {
  $Jacket_Front_Amhole = "0";
}
$Jacket_Behind_Amhole = $_POST["Jacket_Behind_Amhole"];
if (empty($Jacket_Behind_Amhole)) {
  $Jacket_Behind_Amhole = "0";
}
$Jacket_Across_Front = $_POST["Jacket_Across_Front"];
if (empty($Jacket_Across_Front)) {
  $Jacket_Across_Front = "0";
}
$Jacket_Across_Back = $_POST["Jacket_Across_Back"];
if (empty($Jacket_Across_Back)) {
  $Jacket_Across_Back = "0";
}
$Jacket_Unit_Price = $_POST["Jacket_Unit_Price"];
if (empty($Jacket_Unit_Price)) {
  $Jacket_Unit_Price = "0";
}

$result = "-1";  // 新增記錄失敗

   $db = mysqli_connect("localhost", "root", "t19950515");
   @mysqli_query($db,"SET NAMES utf8");
   mysqli_select_db($db, "mirrorworld");


   if (!(empty($Jacket_Note) || empty($Jacket_Amount) || empty($Jacket_Length) || empty($Jacket_Sleeve))) {
   		$sql = "INSERT INTO order_information_jacket "."(Jacket_Note, Jacket_Amount, Jacket_Length, Jacket_Sleeve, Jacket_Shoulder, Jacket_Shoulder_Front, Jacket_Bust, Jacket_Bust_Length, Jacket_Bust_Width, Jacket_Waist, Jacket_Middle_Hip, Jacket_Hip, Jacket_Front_Amhole, Jacket_Behind_Amhole, Jacket_Across_Front, Jacket_Across_Back, Jacket_Unit_Price) VALUES ('$Jacket_Note', '$Jacket_Amount', '$Jacket_Length', '$Jacket_Sleeve', '$Jacket_Shoulder', '$Jacket_Shoulder_Front', '$Jacket_Bust', '$Jacket_Bust_Length', '$Jacket_Bust_Width', '$Jacket_Waist', '$Jacket_Middle_Hip', '$Jacket_Hip', '$Jacket_Front_Amhole', '$Jacket_Behind_Amhole', '$Jacket_Across_Front', '$Jacket_Across_Back', '$Jacket_Unit_Price')";
		   if (mysqli_query($db, $sql)) { // 執行SQL指令
          		$result = "1"; // 新增記錄成功
      		}
   	}
   
echo $result;
mysqli_close($db);
?> 
