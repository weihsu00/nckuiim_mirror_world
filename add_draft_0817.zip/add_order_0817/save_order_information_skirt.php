<?php
header("Expires: Mon, 26 Jul 2015 05:00:00 GMT");

$Skirt_Note = $_POST["Skirt_Note"];

$Skirt_Amount = $_POST["Skirt_Amount"];

$Skirt_Length = $_POST["Skirt_Length"];


$Skirt_Waist = $_POST["Skirt_Waist"];

$Skirt_Middle_Hip = $_POST["Skirt_Middle_Hip"];
if (empty($Skirt_Middle_Hip)) {
  $Skirt_Middle_Hip = "0";
}
$Skirt_Hip = $_POST["Skirt_Hip"];
if (empty($Skirt_Hip)) {
  $Skirt_Hip = "0";
}
$Skirt_Side = $_POST["Skirt_Side"];
if (empty($Skirt_Side)) {
  $Skirt_Side = "0";
}
$Skirt_Style_ID = $_POST["Skirt_Style_ID"];
if (empty($Skirt_Style_ID)) {
  $Skirt_Style_ID = "0";
}
$Skirt_Waistbond_ID = $_POST["Skirt_Waistbond_ID"];
if (empty($Skirt_Waistbond_ID)) {
  $Skirt_Waistbond_ID = "0";
}
$Skirt_Side_Type_ID = $_POST["Skirt_Side_Type_ID"];
if (empty($Skirt_Side_Type_ID)) {
  $Skirt_Side_Type_ID = "0";
}
$Skirt_Unit_Price = $_POST["Skirt_Unit_Price"];
if (empty($Skirt_Unit_Price)) {
  $Skirt_Unit_Price = "0";
}

$result = "-1";  // 新增記錄失敗

   $db = mysqli_connect("localhost", "root", "t19950515");
   @mysqli_query($db,"SET NAMES utf8");
   mysqli_select_db($db, "mirrorworld");


   if (!(empty($Skirt_Note) || empty($Skirt_Amount) || empty($Skirt_Length) || empty($Skirt_Waist))) {
   		$sql = "INSERT INTO order_information_skirt "."(Skirt_Note, Skirt_Amount, Skirt_Length, Skirt_Waist, Skirt_Middle_Hip, Skirt_Hip, Skirt_Side, Skirt_Style_ID, Skirt_Waistbond_ID, Skirt_Side_Type_ID, Skirt_Unit_Price) VALUES ('$Skirt_Note', '$Skirt_Amount', '$Skirt_Length','$Skirt_Waist', '$Skirt_Middle_Hip', '$Skirt_Hip', '$Skirt_Side', '$Skirt_Style_ID', '$Skirt_Waistbond_ID', '$Skirt_Side_Type_ID', '$Skirt_Unit_Price')";
		   if (mysqli_query($db, $sql)) { // 執行SQL指令
          		$result = "1"; // 新增記錄成功
      		}
   	}
   
echo $result;
mysqli_close($db);
?> 
