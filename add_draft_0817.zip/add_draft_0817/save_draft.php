<?php
header("Expires: Mon, 26 Jul 2015 05:00:00 GMT");
   $Title = $_POST["Title"];   // 取得表單欄位值
   $Delivery_Date = $_POST["Delivery_Date"];
   $Account_Name = $_POST["Account_Name"];
   $Account_Unit_ID = $_POST["Account_Unit_ID"];
   $Customer_Name = $_POST["Customer_Name"];
   if (empty($Customer_Name)) {
    $Customer_Name = "0";
   }
   $Customer_Phone = $_POST["Customer_Phone"];
   if (empty($Customer_Phone)) {
    $Customer_Phone = "0";
   }
   $Total_Price = $_POST["Total_Price"];
   if (empty($Total_Price)) {
    $Total_Price = "0";
   }
   $Total_Deposit = $_POST["Total_Deposit"];
   if (empty($Total_Deposit)) {
    $Total_Deposit = "0";
   }
   $Payment_Style = (int)$_POST["Payment_Style_Result"];
      switch ($Payment_Style) {
        case 0:$Payment_Style="現金";
           break;
        case 1:$Payment_Style="匯款";
           break;
        case 2:$Payment_Style="支票";
           break;
        case 3:$Payment_Style="刷卡";
           break;
        case 4:$Payment_Style="其他";
           break;   
   }

$result = "-1";  // 新增記錄失敗

   $db = mysqli_connect("localhost", "root", "t19950515");
   @mysqli_query($db,"SET NAMES utf8");
   mysqli_select_db($db, "mirrorworld");

if (!(empty($Title) || empty($Delivery_Date) || empty($Account_Name) || empty($Account_Unit_ID) || empty($Payment_Style))) {
      $sql = "INSERT INTO order_structure"."(Title, Delivery_Date, Account_Name, Account_Unit_ID, Customer_Name, Customer_Phone, Total_Price, Total_Deposit, Payment_Style)"."VALUES('$Title', '$Delivery_Date', '$Account_Name', '$Account_Unit_ID', '$Customer_Name', '$Customer_Phone', '$Total_Price', '$Total_Deposit', '$Payment_Style')";

       if (mysqli_query($db, $sql)) { // 執行SQL指令
              $result = "1"; // 新增記錄成功
          }
}
   	
   
echo $result;
mysqli_close($db);
?> 
