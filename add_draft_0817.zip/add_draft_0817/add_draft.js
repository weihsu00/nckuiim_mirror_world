
$.noConflict();
jQuery(document).ready(function($) {
  $("form[name=newdraft_form]").submit(function () {
    // 使用HTTP POST方法送出Ajax請求

    $.ajax({
      type: 'POST',
      url: 'save_draft.php',
      data: $('#newdraft_form').serialize(),
      error: function() {
        alert('save_draft.php失敗！');
      },
      success: function (data) {
          var value = parseInt(data);
          if(value==1){
            alert('草稿單新增成功！');
            window.opener.location.reload();
            window.close();
          } 
          else {
            alert('草稿單新增失敗！');
          }
      }
    });
    return false;
  });
});