
$.noConflict();
jQuery(document).ready(function($) {
  $("form").submit(function () {
    // 使用HTTP POST方法送出Ajax請求
    $.ajax({
      type: 'POST',
      url: 'save_order_information.php',
      data: $('#order_information').serialize(),
      success: function (data) {
        var value = parseInt(data); // 取得傳回值
        if (value == 1){
          $('#msg').html("已經成功新增記錄!");
        }
        else{
          $('#msg').html("新增記錄失敗!");
        }
      }
    });
    return false;
  });

});