<?php
header("Expires: Mon, 26 Jul 2015 05:00:00 GMT");
$Company = $_POST["Company"];
$Customer_Name = $_POST["Customer_Name"];
$Height = $_POST["Height"];  
$Weight = $_POST["Weight"];  
$Customer_Phone = $_POST["Customer_Phone"]; 
$result = "-1";  // 新增記錄失敗
if (!(empty($Company) || empty($Customer_Name))) {
   // 有輸入資料
   $db = mysqli_connect("localhost", "root", "t19950515");
   @mysqli_query($db,"SET NAMES utf8");
   mysqli_select_db($db, "contact");
   $sql = "SELECT * FROM order_information WHERE Company = '$Company'";
   $rows = mysqli_query($db, $sql); // 執行SQL查詢              
   $num = mysqli_num_rows($rows); // 取得記錄數  
   if ($num <= 0) {  // 沒有此聯絡人
      $sql = "INSERT INTO order_information ".
"(Company, Customer_Name, Height, Weight, Customer_Phone) VALUES ('$Company', '$Customer_Name', '$Height', '$Weight', '$Customer_Phone')";
      if (mysqli_query($db, $sql)) { // 執行SQL指令
          $result = "1"; // 新增記錄成功
      }     
   }
}
echo $result;
mysqli_close($db);
?> 
